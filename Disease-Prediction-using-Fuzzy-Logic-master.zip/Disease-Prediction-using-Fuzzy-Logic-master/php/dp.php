<?php
$con=mysqli_connect("localhost","root","","diseasedb") or die("couldn't to the  server");
?>